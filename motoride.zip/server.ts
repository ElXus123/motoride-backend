import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  // Socket.io logic for real-time location and ranking sharing
  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join-group", (data: { groupId: string, uid: string }) => {
      socket.join(data.groupId);
      (socket as any).groupId = data.groupId;
      (socket as any).uid = data.uid;
      console.log(`User ${socket.id} (uid: ${data.uid}) joined group: ${data.groupId}`);
    });

    socket.on("update-location", (data) => {
      // Broadcast location and score to everyone else in the group
      // data: { groupId, uid, lat, lng, speed, heading, score, photoURL, displayName, alert }
      socket.to(data.groupId).emit("location-updated", data);
    });

    socket.on("trigger-alert", (data) => {
      // data: { groupId, uid, displayName, type }
      socket.to(data.groupId).emit("alert-triggered", data);
    });

    // WebRTC Signaling
    socket.on("join-voice", (groupId) => {
      socket.join(`${groupId}-voice`);
      // Notify others in the voice room that a new user joined
      socket.to(`${groupId}-voice`).emit("user-joined-voice", socket.id);
    });

    socket.on("leave-voice", (groupId) => {
      socket.leave(`${groupId}-voice`);
      socket.to(`${groupId}-voice`).emit("user-left-voice", socket.id);
    });

    socket.on("webrtc-signal", (data) => {
      // data: { target: string, caller: string, signal: any }
      io.to(data.target).emit("webrtc-signal", {
        caller: socket.id,
        signal: data.signal
      });
    });

    socket.on("disconnect", () => {
      const groupId = (socket as any).groupId;
      const uid = (socket as any).uid; // Assuming I can store uid too
      if (groupId) {
        console.log(`User ${socket.id} (uid: ${uid}) left group: ${groupId}`);
        socket.to(groupId).emit("user-left", { uid });
      }
      console.log("User disconnected:", socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
