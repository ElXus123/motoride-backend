import { useState, useEffect, useRef } from 'react';

export const useLeanAngle = () => {
  const [leanAngle, setLeanAngle] = useState(0);
  const [maxLeanLeft, setMaxLeanLeft] = useState(0);
  const [maxLeanRight, setMaxLeanRight] = useState(0);
  const [permissionGranted, setPermissionGranted] = useState<boolean | null>(null);
  const [calibrationOffset, setCalibrationOffset] = useState(0);
  const smoothedAngleRef = useRef(0);

  const requestPermission = async () => {
    if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
      try {
        const permissionState = await (DeviceOrientationEvent as any).requestPermission();
        if (permissionState === 'granted') {
          setPermissionGranted(true);
        } else {
          setPermissionGranted(false);
        }
      } catch (error) {
        console.error("Error requesting device orientation permission:", error);
        setPermissionGranted(false);
      }
    } else {
      // Non-iOS 13+ devices
      setPermissionGranted(true);
    }
  };

  const [rawAngle, setRawAngle] = useState(0);

  useEffect(() => {
    if (!permissionGranted) return;

    const handleOrientation = (event: DeviceOrientationEvent) => {
      let angle = 0;
      const isLandscape = window.innerWidth > window.innerHeight;
      const orientation = window.orientation || 0;

      // Isolate lateral lean (roll)
      // On most devices:
      // Portrait: gamma is roll, beta is pitch
      // Landscape: beta is roll, gamma is pitch
      
      let roll = 0;
      if (isLandscape) {
        // In landscape, beta is the lateral tilt
        roll = event.beta || 0;
        if (orientation === -90 || orientation === 270) {
          roll = -roll;
        }
      } else {
        // In portrait, gamma is the lateral tilt
        roll = event.gamma || 0;
      }

      // To make it "real" and ignore pitch (acceleration/braking), 
      // we can use a small threshold and ensure we are only detecting lateral movement.
      // We also cap it at 60 degrees as that's a realistic max for most riders.
      if (roll > 60) roll = 60;
      if (roll < -60) roll = -60;

      setRawAngle(roll);
      
      // Low-pass filter for smoother, more realistic lean angle
      // We use a slightly more aggressive filter for "real" feel
      const alpha = 0.1; // Smoothing factor (lower = smoother but slower)
      smoothedAngleRef.current = smoothedAngleRef.current + alpha * (roll - smoothedAngleRef.current);
      
      // Dead zone to prevent jitter when upright
      let finalAngle = smoothedAngleRef.current - calibrationOffset;
      if (Math.abs(finalAngle) < 1) finalAngle = 0;
      
      const roundedAngle = Math.round(finalAngle);
      setLeanAngle(roundedAngle);

      if (roundedAngle < 0 && Math.abs(roundedAngle) > maxLeanLeft) {
        setMaxLeanLeft(Math.abs(roundedAngle));
      } else if (roundedAngle > 0 && roundedAngle > maxLeanRight) {
        setMaxLeanRight(roundedAngle);
      }
    };

    window.addEventListener('deviceorientation', handleOrientation);
    return () => window.removeEventListener('deviceorientation', handleOrientation);
  }, [permissionGranted, maxLeanLeft, maxLeanRight, calibrationOffset]);

  const resetMaxLean = () => {
    setMaxLeanLeft(0);
    setMaxLeanRight(0);
  };

  const calibrate = () => {
    setCalibrationOffset(smoothedAngleRef.current);
  };

  const applyCalibrationStep = (error: number, strength: number = 0.005) => {
    setCalibrationOffset(prev => prev + error * strength);
  };

  return { leanAngle, maxLeanLeft, maxLeanRight, permissionGranted, requestPermission, resetMaxLean, calibrate, applyCalibrationStep };
};
