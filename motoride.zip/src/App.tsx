import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import MainApp from './components/MainApp';
import { AlertTriangle, RefreshCcw } from 'lucide-react';

const AppContent = () => {
  const { user, loading, error } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-6 text-center">
        <div className="w-20 h-20 bg-orange-500/10 rounded-full flex items-center justify-center mb-6">
          <AlertTriangle size={40} className="text-orange-500" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">App en Mantenimiento</h1>
        <p className="text-zinc-400 max-w-md mb-8">
          {error === 'quota' 
            ? "La cuota gratuita de la base de datos se ha agotado por hoy. El servicio se restablecerá automáticamente mañana."
            : "No se pudo conectar con el servidor. Por favor, comprueba tu conexión a internet o asegúrate de que no tienes un bloqueador de anuncios interfiriendo."}
        </p>
        <button 
          onClick={() => window.location.reload()}
          className="flex items-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-white px-6 py-3 rounded-xl transition-colors font-semibold"
        >
          <RefreshCcw size={18} />
          Reintentar
        </button>
      </div>
    );
  }
  
  return user ? <MainApp /> : <Login />;
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
